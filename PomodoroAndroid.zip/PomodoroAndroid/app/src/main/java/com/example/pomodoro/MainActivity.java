package com.example.pomodoro;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final long FOCUS_MS = 25 * 60 * 1000L;
    private static final long BREAK_MS = 5 * 60 * 1000L;
    private TextView timerText, sessionLabel, statusText, completedText, focusChip, breakChip;
    private Button startButton, resetButton;
    private CountDownTimer timer;
    private long remainingMs = FOCUS_MS;
    private boolean isFocus = true;
    private boolean running = false;
    private int completed = 0;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        timerText = findViewById(R.id.timerText);
        sessionLabel = findViewById(R.id.sessionLabel);
        statusText = findViewById(R.id.statusText);
        completedText = findViewById(R.id.completedText);
        focusChip = findViewById(R.id.focusChip);
        breakChip = findViewById(R.id.breakChip);
        startButton = findViewById(R.id.startButton);
        resetButton = findViewById(R.id.resetButton);
        startButton.setOnClickListener(v -> toggleTimer());
        resetButton.setOnClickListener(v -> resetTimer());
        focusChip.setOnClickListener(v -> selectSession(true));
        breakChip.setOnClickListener(v -> selectSession(false));
        render();
    }

    private void toggleTimer() {
        if (running) { pauseTimer(); return; }
        running = true;
        statusText.setText("正在专注，保持节奏");
        startButton.setText("暂停");
        timer = new CountDownTimer(remainingMs, 1000) {
            @Override public void onTick(long millisUntilFinished) {
                remainingMs = millisUntilFinished;
                renderTime();
            }
            @Override public void onFinish() {
                running = false;
                if (isFocus) {
                    completed++;
                    Toast.makeText(MainActivity.this, "番茄完成！休息一下吧。", Toast.LENGTH_LONG).show();
                    isFocus = false;
                    remainingMs = BREAK_MS;
                } else {
                    Toast.makeText(MainActivity.this, "休息结束，准备开始下一轮吧。", Toast.LENGTH_LONG).show();
                    isFocus = true;
                    remainingMs = FOCUS_MS;
                }
                render();
            }
        }.start();
        render();
    }

    private void pauseTimer() {
        if (timer != null) timer.cancel();
        running = false;
        statusText.setText("已暂停，准备好再继续");
        startButton.setText("继续");
        render();
    }

    private void resetTimer() {
        if (timer != null) timer.cancel();
        running = false;
        remainingMs = isFocus ? FOCUS_MS : BREAK_MS;
        statusText.setText("准备开始");
        startButton.setText(isFocus ? "开始专注" : "开始休息");
        render();
    }

    private void selectSession(boolean focus) {
        if (running) pauseTimer();
        if (timer != null) timer.cancel();
        isFocus = focus;
        remainingMs = isFocus ? FOCUS_MS : BREAK_MS;
        statusText.setText("准备开始");
        render();
    }

    private void render() {
        sessionLabel.setText(isFocus ? "专注时间" : "休息时间");
        startButton.setText(running ? "暂停" : (remainingMs == (isFocus ? FOCUS_MS : BREAK_MS) ? (isFocus ? "开始专注" : "开始休息") : "继续"));
        focusChip.setText(isFocus ? "● 专注 25 分钟" : "专注 25 分钟");
        breakChip.setText(isFocus ? "休息 5 分钟" : "● 休息 5 分钟");
        focusChip.setTextColor(isFocus ? 0xFFFFFFFF : 0xFF8E7772);
        breakChip.setTextColor(isFocus ? 0xFF8E7772 : 0xFFFFFFFF);
        focusChip.setBackgroundResource(isFocus ? R.drawable.chip_active : R.drawable.chip_idle);
        breakChip.setBackgroundResource(isFocus ? R.drawable.chip_idle : R.drawable.chip_active);
        completedText.setText("今日完成 " + completed + " 个番茄");
        renderTime();
    }

    private void renderTime() {
        long totalSeconds = Math.max(0, (remainingMs + 999) / 1000);
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        timerText.setText(String.format(java.util.Locale.getDefault(), "%02d:%02d", minutes, seconds));
    }

    @Override protected void onDestroy() {
        if (timer != null) timer.cancel();
        super.onDestroy();
    }
}
