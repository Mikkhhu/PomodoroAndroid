# 番茄钟 Android App

一个原生 Android Java 示例项目，包含：
- 25 分钟专注 / 5 分钟休息
- 开始、暂停、继续、重置
- 手动切换专注与休息模式
- 番茄完成计数
- 简洁的暖色系界面

## 如何运行
1. 安装 Android Studio（建议使用带 Android SDK 的当前稳定版）。
2. 在 Android Studio 中打开 `PomodoroAndroid` 文件夹。
3. 等待 Gradle 同步完成。
4. 连接 Android 手机并打开 USB 调试，或创建模拟器。
5. 点击 Run 运行应用。

本压缩包是 Android Studio 项目源代码，不是已签名 APK；当前环境未提供 Android SDK/Gradle 构建环境，因此没有预先编译 APK。
